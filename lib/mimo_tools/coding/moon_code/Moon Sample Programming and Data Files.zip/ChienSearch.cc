//  Program: ChienSearch.cc
//  Todd K. Moon

// Copyright 2004 by Todd K. Moon
// Permission is granted to use this program/data
// for educational/research only

#include "ChienSearch.h"

GFNUM2m *
ChienSearch::Search(GFNUM2m *poly, int nu)
// Lambda(x) = poly[0] + poly[1] x + ... + poly[nu]x^nu
{

   // Fill in the blanks

}
	  


/*
Local Variables:
compile-command: "g++ -c -g ChienSearch.cc"
End:
*/


