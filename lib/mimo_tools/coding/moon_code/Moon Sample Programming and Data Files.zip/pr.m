function pr(v)

fprintf(1,'%s=',inputname(1));
fprintf(1,'%g ',v);
fprintf(1,'\n');