// Copyright 2004 by Todd K. Moon
// Permission is granted to use this program/data
// for educational/research only
