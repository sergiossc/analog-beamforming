// declarations for random number generators

double gran(void);  // in gran.c
double uran(void);  // in uran.c
void gran2(double &r1, double & r1);  // in gran2.cc
