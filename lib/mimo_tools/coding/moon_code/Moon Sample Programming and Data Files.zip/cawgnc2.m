function c = cawgnc2(EcN0)
%

% Copyright 2004 by Todd K. Moon
% Permission is granted to use this program/data
% for educational/research only


c = 0.5*log2(1+EcN0);
