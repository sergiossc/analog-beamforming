//  Program: berlmass.cc --- implement the Berlekamp-Massey algorithm

#include "polynomialT.h"

template <class T> polynomialT<T>
berlmass(const T* s, int n)
// s = input coefficients s[0],s[1],... s[n-1]
// returns = final connection polynomial
{

   // fill in the blanks ...

   return c;
}


/*
Local Variables:
compile-command: "g++ -g berlmass.cc"
End:
*/


