function C = cawgnc(sigmain)

% Copyright 2004 by Todd K. Moon
% Permission is granted to use this program/data
% for educational/research only

C = 0.5*log2(1 + 1./sigmain.^2);
